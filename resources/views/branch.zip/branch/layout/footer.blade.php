<footer class="page-footer">
    <div class="footer-copyright">
        <div class="container"></div>
    </div>
</footer>
<div id="card-stats">
	<div class="row">
		@if($job)
		<h4 class="header">
			Current Job: {{ $job->job_desc }}<br>
			Duration: {{ date('d M Y',strtotime($job->start_date)) }} - {{ date('d M Y',strtotime($job->end_date)) }}
		</h4>
		@else
		<h4 class="header">Currently No Job Available</h4>
		@endif
	</div>
</div>